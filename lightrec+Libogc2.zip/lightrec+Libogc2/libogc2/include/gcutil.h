#ifndef __GCUTIL_H__
#define __GCUTIL_H__

#ifndef ATTRIBUTE_ALIGN
# define ATTRIBUTE_ALIGN(v)					__attribute__((aligned(v)))
#endif
#ifndef ATTRIBUTE_PACKED
# define ATTRIBUTE_PACKED					__attribute__((packed))
#endif

#endif /* _GCUTIL_H */

